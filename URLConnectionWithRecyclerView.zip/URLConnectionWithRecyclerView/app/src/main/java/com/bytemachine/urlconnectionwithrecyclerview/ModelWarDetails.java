package com.bytemachine.urlconnectionwithrecyclerview;


class ModelWarDetails {

    private String name;
    private String location;
    private String attacker_king;
    private String defender_king;


    String getName() {
        return name;
    }

    void setName(String name) {
        this.name = name;
    }

     String getLocation() {
        return location;
    }

    void setLocation(String location) {
        this.location = location;
    }

    String getAttacker_king() {
        return attacker_king;
    }

    void setAttacker_king(String attacker_king) {
        this.attacker_king = attacker_king;
    }

    String getDefender_king() {
        return defender_king;
    }

    void setDefender_king(String defender_king) {
        this.defender_king = defender_king;
    }
}
